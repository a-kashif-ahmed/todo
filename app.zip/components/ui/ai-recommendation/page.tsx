// ============================================================
// FILE 3: src/components/ui/ai-recommendation/page.tsx
// Dynamic,fetches latest open incident and shows it
// ============================================================
 
"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { SvgIcon } from "../svgIcon/page";
 
const AiIcon = (
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M8 13H10L10.15 11.75C10.2833 11.7 10.4042 11.6417 10.5125 11.575C10.6208 11.5083 10.7167 11.4333 10.8 11.35L11.95 11.85L12.95 10.15L11.95 9.4C11.9833 9.26667 12 9.13333 12 9C12 8.86667 11.9833 8.73333 11.95 8.6L12.95 7.85L11.95 6.15L10.8 6.65C10.7167 6.56667 10.6208 6.49167 10.5125 6.425C10.4042 6.35833 10.2833 6.3 10.15 6.25L10 5H8L7.85 6.25C7.71667 6.3 7.59583 6.35833 7.4875 6.425C7.37917 6.49167 7.28333 6.56667 7.2 6.65L6.05 6.15L5.05 7.85L6.05 8.6C6.01667 8.73333 6 8.86667 6 9C6 9.13333 6.01667 9.26667 6.05 9.4L5.05 10.15L6.05 11.85L7.2 11.35C7.28333 11.4333 7.37917 11.5083 7.4875 11.575C7.59583 11.6417 7.71667 11.7 7.85 11.75L8 13ZM9 10.5C8.58333 10.5 8.22917 10.3542 7.9375 10.0625C7.64583 9.77083 7.5 9.41667 7.5 9C7.5 8.58333 7.64583 8.22917 7.9375 7.9375C8.22917 7.64583 8.58333 7.5 9 7.5C9.41667 7.5 9.77083 7.64583 10.0625 7.9375C10.3542 8.22917 10.5 8.58333 10.5 9C10.5 9.41667 10.3542 9.77083 10.0625 10.0625C9.77083 10.3542 9.41667 10.5 9 10.5ZM3 20V15.7C2.05 14.8333 1.3125 13.8208 0.7875 12.6625C0.2625 11.5042 0 10.2833 0 9C0 6.5 0.875 4.375 2.625 2.625C4.375 0.875 6.5 0 9 0C11.0833 0 12.9292 0.6125 14.5375 1.8375C16.1458 3.0625 17.1917 4.65833 17.675 6.625L18.975 11.75C19.0583 12.0667 19 12.3542 18.8 12.6125C18.6 12.8708 18.3333 13 18 13H16V16C16 16.55 15.8042 17.0208 15.4125 17.4125C15.0208 17.8042 14.55 18 14 18H12V20H3Z" fill="#DDB7FF"/>
  </svg>
);
 
interface Incident {
  id: string;
  workflow_id: string;
  error_message: string | null;
  impact_summary: string | null;
  root_cause: string | null;
}
 
export default function AiRecommendation() {
  const [incident, setIncident] = useState<Incident | null>(null);
  const [workflowName, setWorkflowName] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const router = useRouter();
 
  useEffect(() => {
    // Fetch latest open incident
    fetch("/api/incidents?status=open")
      .then(r => r.json())
      .then(async data => {
        const first = data.incidents?.[0];
        if (!first) { setLoading(false); return; }
        setIncident(first);
 
        // Fetch workflow name for context
        const wfData = await fetch(`/api/workflows/${first.workflow_id}`).then(r => r.json());
        setWorkflowName(wfData.workflow?.name || "a workflow");
        setLoading(false);
      });
  }, []);
 
  // Nothing to show if no open incidents
  if (loading || !incident) return null;
 
  const message = incident.impact_summary
    || incident.error_message
    || `We detected an issue that may impact ${workflowName}.`;
 
  return (
    <div className="flex items-start gap-4 bg-surface-2 border border-[#DDB7FF33] rounded-xl px-5 py-4">
 
      {/* Icon box */}
      <div className="w-9 h-9 rounded-lg bg-[#DDB7FF1A] border border-[#DDB7FF33] flex items-center justify-center flex-shrink-0 mt-0.5">
        <SvgIcon svg={AiIcon} size={18} color="#DDB7FF" />
      </div>
 
      {/* Text + button */}
      <div className="flex flex-col gap-3 flex-1">
        <div>
          <h3 className="text-sm font-semibold text-text-primary mb-1">
            AI Recommendation
          </h3>
          <p className="text-sm text-text-muted leading-relaxed">
            {message}
          </p>
        </div>
 
        <div className="flex items-center gap-2">
          <button
            onClick={() => router.push(`/workflows/${incident.workflow_id}/incidents/${incident.id}`)}
            className="self-start text-sm font-medium bg-[#DDB7FF33] hover:bg-[#DDB7FF4D] text-[#DDB7FF] border border-[#DDB7FF44] rounded-lg px-4 py-1.5 transition-colors"
          >
            Analyze Impact →
          </button>
         
        </div>
      </div>
 
    </div>
  );
}
 