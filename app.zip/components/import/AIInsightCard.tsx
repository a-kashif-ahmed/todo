
// ─────────────────────────────────────────────────────────────
// src/components/import/AIInsightCard.tsx
// ─────────────────────────────────────────────────────────────

"use client";

interface ImportedSummary {
  summary: string;
  complexity: "low" | "medium" | "high";
  node_count: number;
  risks: string[];
  optimization_opportunities: string[];
}

interface Props {
  summary?: ImportedSummary | null;
  loading?: boolean;
}

const complexityStyle: Record<string, string> = {
  low: "text-status-success",
  medium: "text-status-warning",
  high: "text-status-error",
};

export default function AIInsightCard({ summary, loading }: Props) {
  // Nothing imported yet — original "connect your account" pitch.
  if (!summary && !loading) {
    return (
      <div className="bg-surface-2 border border-border rounded-xl p-5">
        <div className="flex items-center gap-2 mb-3">
          <span className="text-brand-orange text-sm">◎</span>
          <span className="text-xs font-bold tracking-wide text-brand-orange">AI INSIGHT</span>
        </div>
        <p className="text-sm text-text-muted leading-relaxed">
          FlowLens Copilot will summarize your workflow the moment it's imported,
          node count, complexity, risks, and optimization opportunities,
          before you even open it.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-surface-2 border border-border rounded-xl p-5">
      <div className="flex items-center gap-2 mb-3">
        <span className="text-brand-orange text-sm">◎</span>
        <span className="text-xs font-bold tracking-wide text-brand-orange">AI INSIGHT</span>
      </div>

      {loading ? (
        <div className="space-y-2">
          <div className="h-3 w-full bg-surface-3 rounded animate-pulse" />
          <div className="h-3 w-2/3 bg-surface-3 rounded animate-pulse" />
        </div>
      ) : summary ? (
        <>
          <p className="text-sm text-text-muted leading-relaxed mb-3">
            {summary.summary}
          </p>
          <div className="flex flex-wrap items-center gap-x-1.5 gap-y-1 text-xs">
            <span className="text-text-primary font-medium">{summary.node_count} nodes</span>
            <span className="text-text-muted">·</span>
            <span className={`font-medium ${complexityStyle[summary.complexity]}`}>
              {summary.complexity} complexity
            </span>
            <span className="text-text-muted">·</span>
            <span className={summary.risks.length > 0 ? "text-status-warning font-medium" : "text-text-muted"}>
              {summary.risks.length} risk{summary.risks.length === 1 ? "" : "s"}
            </span>
            <span className="text-text-muted">·</span>
            <span className="text-text-muted font-medium">
              {summary.optimization_opportunities.length} optimization{summary.optimization_opportunities.length === 1 ? "" : "s"}
            </span>
          </div>
        </>
      ) : null}
    </div>
  );
}
