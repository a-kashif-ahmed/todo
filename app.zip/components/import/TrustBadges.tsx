// ─────────────────────────────────────────────────────────────
// src/components/import/TrustBadges.tsx
// ─────────────────────────────────────────────────────────────

import { ShieldCheck, History, GitBranch, Sparkles } from "lucide-react";
import Link from "next/link";

export default function TrustBadges() {
  const badges = [
    { icon: ShieldCheck, label: "End-to-end encryption active" },
    { icon: History, label: "Auto-versioning enabled" },
    { icon: GitBranch, label: "Supports OpenAPI v3 & JSON Schema" },
  ];

  return (
    <div className="flex flex-col items-center gap-3 mt-8">
      <div className="flex items-center justify-center gap-8 flex-wrap">
        {badges.map(({ icon: Icon, label }) => (
          <span key={label} className="flex items-center gap-2 text-xs text-text-muted">
            <Icon size={13} />
            {label}
          </span>
        ))}
      </div>

      {/* AI processing disclosure — imported workflow content is sent to
          FlowLens Copilot to generate the summary/complexity/risk insight
          above, so this needs to be visible right where import happens. */}
      <p className="flex items-center gap-1.5 text-[11px] text-text-muted">
        <Sparkles size={12} className="text-brand-orange" />
        Node names and structure are sent to FlowLens Copilot for AI analysis. Credentials are never included.
        {" "}
        <Link href="/settings" className="text-brand-orange hover:underline">
          Manage AI &amp; privacy settings
        </Link>
      </p>
    </div>
  );
}
