// ─────────────────────────────────────────────────────────────
// src/components/diff/AIExplanationCard.tsx
// ─────────────────────────────────────────────────────────────

"use client";

interface SuggestedFix {
  description: string;
  node_id?: string;
  field?: string;
}

interface Props {
  // Semantic diff explanation from /api/diff — always available once a diff
  // has been computed, regardless of whether an incident is linked. This is
  // now the primary content of the card.
  explanation: string;
  // Incident-linked root-cause analysis — optional, only present when an
  // open incident matches these two snapshots. Adds business-impact framing
  // and a suggested fix on top of the semantic explanation above.
  rootCause?: string;
  confidence?: number;
  businessImpact?: string;
  impactSummary?: string;
  suggestedFix?: SuggestedFix | null;
  onApplyFix?: () => void;
  applying?: boolean;
}

export default function AIExplanationCard({
  explanation,
  rootCause,
  confidence,
  businessImpact,
  impactSummary,
  suggestedFix,
  onApplyFix,
  applying,
}: Props) {
  const hasIncidentAnalysis = !!rootCause;

  return (
    <div className="bg-surface-2 border border-border rounded-xl p-5">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-text-primary">AI Explanation</h3>
        {hasIncidentAnalysis && typeof confidence === "number" && (
          <span className="text-xs text-text-muted">
            {Math.round(confidence * 100)}% confidence
          </span>
        )}
      </div>

      {/* Primary content — always shown once a diff exists */}
      <p className="text-sm text-text-muted leading-relaxed mb-3">
        {explanation}
      </p>

      {/* Incident root cause — only when an incident links these snapshots */}
      {hasIncidentAnalysis && (
        <div className="bg-surface rounded-lg border border-border-light px-3 py-2.5 mb-3">
          <p className="text-[11px] text-text-muted uppercase tracking-wide mb-1">Root Cause</p>
          <p className="text-xs text-text-muted leading-relaxed">{rootCause}</p>
        </div>
      )}

      {businessImpact && (
        <div className="bg-surface rounded-lg border border-border-light px-3 py-2.5 mb-3">
          <p className="text-[11px] text-text-muted uppercase tracking-wide mb-1">Business Impact</p>
          <p className="text-xs text-text-muted leading-relaxed">{businessImpact}</p>
        </div>
      )}

      {impactSummary && (
        <div className="bg-surface rounded-lg border border-border-light px-3 py-2.5 mb-4">
          <p className="text-[11px] text-text-muted uppercase tracking-wide mb-1">Impact</p>
          <p className="text-xs text-text-muted leading-relaxed">{impactSummary}</p>
        </div>
      )}

      {suggestedFix && (
        <div className="flex items-center justify-between bg-brand-orange/10 border border-brand-orange/20 rounded-lg px-3 py-2.5">
          <p className="text-xs text-brand-orange flex-1 mr-3">
            {suggestedFix.description}
          </p>
          {onApplyFix && (
            <button
              onClick={onApplyFix}
              disabled={applying}
              className="text-xs font-medium bg-brand-orange text-text-primary rounded px-3 py-1.5 whitespace-nowrap disabled:opacity-60 hover:opacity-90 transition-opacity"
            >
              {applying ? "Applying..." : "Apply Fix"}
            </button>
          )}
        </div>
      )}
    </div>
  );
}
