// ─────────────────────────────────────────────────────────────
// src/app/api/incidents/[id]/analyse/route.ts
// POST /api/incidents/:id/analyse — run AI root cause analysis
// ─────────────────────────────────────────────────────────────

import { NextResponse, NextRequest } from "next/server";
import { getAuthContext } from "@/lib/supabase/auth-helper";
import { diffWorkflows } from "@/lib/services/diff";
import { analyseRootCause } from "@/lib/services/ai";
import { assertAiAllowed } from "@/lib/services/aiSettings";



export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await getAuthContext();
  const { id } = await params;
  if (ctx.error) return ctx.error;
  const { teamId, db } = ctx;

  const { data: incident } = await db
    .from("flowlens_incidents")
    .select(`
      *,
      snap_before:snapshot_before(normalised),
      snap_after:snapshot_after(normalised)
    `)
    .eq("id", id)
    .eq("team_id", teamId)
    .single();

  if (!incident) {
    return NextResponse.json({ error: "Incident not found" }, { status: 404 });
  }

  // Return cached result — never call AI twice for same incident
  if (incident.root_cause) {
    return NextResponse.json({
      cached: true,
      analysis: {
        problem: incident.problem,
        root_cause: incident.root_cause,
        confidence: incident.confidence,
        business_impact: incident.business_impact,
        impact_summary: incident.impact_summary,
        what_changed: incident.what_changed,
        suggested_fix: incident.suggested_fix,
        execution_evidence: incident.execution_evidence,
        recovery_steps: incident.recovery_steps,
      },
    });
  }

  if (!incident.snap_before || !incident.snap_after) {
    return NextResponse.json(
      { error: "Incident is missing one or both snapshots" },
      { status: 400 }
    );
  }

  // Gate only applies to a fresh AI call — the cached-result branch above
  // still returns previously-generated analysis even if AI is currently
  // disabled, since that's reading stored data, not making a new AI call.
  const gate = await assertAiAllowed(db, teamId, "analysis");
  if (!gate.allowed) {
    return NextResponse.json({ error: gate.reason }, { status: 403 });
  }

  const diff = diffWorkflows(
    incident.snap_before.normalised,
    incident.snap_after.normalised
  );

  const analysis = await analyseRootCause(diff, incident.error_message);

  // Store result on incident. The four original columns always exist; the
  // new business-impact fields are best-effort until a migration adds them
  // (problem, business_impact, what_changed, execution_evidence, recovery_steps).
  try {
    await db
      .from("flowlens_incidents")
      .update({
        problem: analysis.problem,
        root_cause: analysis.root_cause,
        confidence: analysis.confidence,
        business_impact: analysis.business_impact,
        impact_summary: analysis.impact_summary,
        what_changed: analysis.what_changed,
        suggested_fix: analysis.suggested_fix,
        execution_evidence: analysis.execution_evidence,
        recovery_steps: analysis.recovery_steps,
      })
      .eq("id", id);
  } catch (e) {
    console.error("Storing extended incident analysis failed, retrying with legacy columns only:", e);
    await db
      .from("flowlens_incidents")
      .update({
        root_cause: analysis.root_cause,
        confidence: analysis.confidence,
        impact_summary: analysis.impact_summary,
        suggested_fix: analysis.suggested_fix,
      })
      .eq("id", id);
  }

  return NextResponse.json({ cached: false, analysis, diff });
}


