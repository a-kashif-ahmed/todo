// ─────────────────────────────────────────────────────────────
// src/app/(dashboard)/history/page.tsx
// Figma: History,left timeline + right Builder Insights sidebar
// ─────────────────────────────────────────────────────────────

"use client";
import { useState, useEffect } from "react";
import { GitBranch, Clock } from "lucide-react";
import Link from "next/link";
import HistoryTimeline from "@/components/history/HistoryTimeline";

interface HistoryEntry {
  id: string;
  workflow_id: string;
  action: string;
  actor_type: "user" | "system" | "ai";
  created_at: string;
  profiles?: { display_name: string };
  // Joined from flowlens_snapshots via /api/history — undefined if the
  // entry has no linked snapshot, null if the snapshot has no AI summary yet.
  snapshot?: { ai_summary?: { summary: string; complexity?: "low" | "medium" | "high" } | null } | null;
}

function dateLabel(iso: string) {
  const d = new Date(iso);
  const now = new Date();
  const diff = Math.floor((now.getTime() - d.getTime()) / 86400000);
  return diff === 0 ? "Today" : diff === 1 ? "Yesterday" : d.toLocaleDateString(undefined, { month: "long", day: "numeric" });
}

export default function HistoryPage() {
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/history")
      .then(r => r.json())
      .then(data => { setHistory(data.history || []); setLoading(false); });
  }, []);

  const isEmpty = !loading && history.length === 0;

  // Simple team-wide stat for the sidebar,how many entries in this list
  // already have an AI summary attached, to reflect real Copilot coverage
  // instead of a static claim.
  const aiSummarizedCount = history.filter(e => e.snapshot?.ai_summary?.summary).length;

  const timelineEntries = history.map(e => ({
    id: e.id,
    action: e.action,
    actor: e.profiles?.display_name || "System",
    actorType: e.actor_type,
    workflowName: e.workflow_id,
    workflowId: e.workflow_id,
    time: new Date(e.created_at).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" }),
    date: dateLabel(e.created_at),
    aiSummary: e.snapshot?.ai_summary || null,
  }));

  return (
    <div className="flex h-full overflow-hidden">

      {/* ── LEFT: Timeline ── */}
      <div className="flex-1 overflow-y-auto p-8 pr-6">
        {isEmpty ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="w-24 h-24 rounded-2xl bg-surface-2 border border-dashed border-border flex items-center justify-center mb-6">
              <Clock size={32} className="text-gray-600" />
            </div>
            <h2 className="text-2xl font-bold text-text-primary mb-2">No activity tracked yet</h2>
            <p className="text-text-muted text-sm max-w-sm mb-8 leading-relaxed">
              Once you start deploying workflows or making changes, your audit log will appear here for versioning and recovery.
            </p>
            <div className="flex gap-3">
              <Link href="/workflows" className="flex items-center gap-2 bg-brand-blue text-text-primary text-sm font-medium rounded-lg px-5 py-2.5 hover:opacity-90 transition-opacity">
                <GitBranch size={14} /> Go to Workflows
              </Link>
              <Link href="/workflows" className="flex items-center gap-2 bg-surface-2 border border-border text-text-primary text-sm font-medium rounded-lg px-5 py-2.5 hover:border-gray-500 transition-colors">
                Import JSON
              </Link>
            </div>
          </div>
        ) : (
          <>
            <h1 className="text-2xl font-semibold text-text-primary mb-6">History</h1>
            {loading ? (
              <p className="text-text-muted text-sm">Loading...</p>
            ) : (
              <HistoryTimeline entries={timelineEntries} />
            )}
          </>
        )}
      </div>

      {/* ── RIGHT: Builder Insights sidebar ── */}
      <div className="w-72 flex-shrink-0 border-l border-border overflow-y-auto p-6 space-y-5 scrollbar">
        <div className="flex items-center gap-2">
          <span className="text-brand-orange">◎</span>
          <h2 className="text-base font-semibold text-text-primary">Builder Insights</h2>
        </div>
        <p className="text-xs text-text-muted">Maximize your automation visibility</p>

        <div className="bg-surface-2 border border-border rounded-xl p-4">
          <p className="text-[10px] font-bold text-brand-orange tracking-wider mb-2">✦ AI SUMMARIES</p>
          <p className="text-xs text-text-muted leading-relaxed">
            {loading
              ? "Loading..."
              : `${aiSummarizedCount} of ${history.length} recent entries have an AI-generated summary of what changed and why it matters.`}
          </p>
        </div>

        <div className="bg-surface-2 border border-border rounded-xl p-4">
          <p className="text-[10px] font-bold text-status-warning tracking-wider mb-2">◉ ANOMALY DETECTION</p>
          <p className="text-xs text-text-muted leading-relaxed">
            FlowLens Copilot constantly monitors your history to find patterns. If a workflow begins failing due to a logic loop, it will highlight the exact version where it started.
          </p>
        </div>

        {/* Version engine banner */}
        <div className="bg-surface-2 border border-border rounded-xl overflow-hidden">
          <div className="bg-gradient-to-br from-surface-3 to-surface-2 h-24 flex items-center justify-center">
           
          </div>
          <div className="px-4 py-3">
            <p className="text-xs font-semibold text-text-primary">Version Engine Active</p>
          </div>
        </div>

        {/* Recent system health */}
        <div>
          <p className="text-[10px] font-semibold text-text-muted uppercase tracking-wide mb-3">Recent System Health</p>
          <div className="space-y-2">
            {[
              { label: "Log Engine", status: "Operational" },
              { label: "Auth Audit",  status: "Synchronized" },
            ].map(item => (
              <div key={item.label} className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full border-2 border-brand-blue flex items-center justify-center flex-shrink-0">
                  <span className="w-1 h-1 rounded-full bg-brand-blue" />
                </span>
                <span className="text-xs text-text-muted">{item.label}: <span className="text-gray-300">{item.status}</span></span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
